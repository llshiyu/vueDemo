<template>
  <div class="home-page">
    <div class="search-box">
      <input type="text" class="search-input" v-model="searchItem">
      <div @click="add" class="search-btn btn">新建</div>
    </div>


    <ul class="list-box">
      <li v-for="(item,index) in listArr" :key="index">
        <list :item="item" :index="index" @del="del(index)" @update="update(index)" @save="save(index)"></list>
      </li>
    </ul>
  </div>
</template>

<script>
  import list from '@/components/list.vue'

  export default {
    components: {list},
    data() {
      return {
        searchItem: '',
        listArr: []
      }
    },
    mounted() {
    },
    methods: {
      add() {
        if (this.searchItem) {
          this.listArr.push(
            {
              cont: this.searchItem,
              isUpdate: false
            }
          );
          this.searchItem = ''
        }else{
          this.$message({
            message: '请输入内容',
            type: 'warning'
          });
        }
      },
      del(i) {
        if (this.listArr[i]) this.listArr.splice(i, 1);
        this.$message({
          type: 'success',
          message: '删除成功!'
        });
      },
      update(i) {
        this.listArr[i]['isUpdate'] = true
      },
      save(i) {
        this.listArr[i]['isUpdate'] = false
        this.$message({
          type: 'success',
          message: '保存成功!'
        });
      }
    }
  }
</script>

<style>
  .btn {
    width: 60px;
    height: 30px;
    line-height: 30px;
    text-align: center;
    display: inline-block;
    border-radius: 4px;
    margin-left: 20px;
    cursor: pointer;
  }

  .btn:hover {
    font-weight: 700;
  }

  .search-btn {
    border: 1px solid #409EFF;
    background-color: #409EFF;
    color: #fff;
  }

  .del-btn {
    border: 1px solid #fff;
    background-color: #fff;
    color: #333;
  }

  .save-btn {
    border: 1px solid #67c23a;
    background-color: #67c23a;
    color: #fff;
  }

  .update-btn {
    border: 1px solid #409EFF;
    background-color: #409EFF;
    color: #fff;
  }

  .home-page .list-box li {
    list-style-type: none;
    border: 1px solid #333;
    margin: 10px;
    padding: 20px;
    text-align: left;
    border-radius: 4px;
  }

  .home-page .list-box li .list-input {
    width: 100px;
    display: inline-block;
  }

  .home-page .list-box li .list-title {
    width: 100px;
    display: inline-block;
  }
</style>
